function y = filtroRetangular(M)
    y = ones(1, M);
end